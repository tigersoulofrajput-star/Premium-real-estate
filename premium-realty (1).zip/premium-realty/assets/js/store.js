/* store.js - one data API with two back ends.
   Demo mode     : everything lives in this browser (IndexedDB). Works with no server.
   Supabase mode : set supabaseUrl + supabaseAnonKey in config.js. Data goes to your Supabase
                   project through its REST API (no extra library needed). */
(function () {
  'use strict';
  const RE = window.RE;
  const cfg = RE.cfg;
  const SB_MODE = !!(cfg.supabaseUrl && cfg.supabaseAnonKey);

  const DEFAULT_SETTINGS = {
    brand: 'Aurelia Estates',
    tagline: 'Homes worth coming home to',
    heroTitle: 'Find the home that fits the way you live',
    heroSub: 'Villas, penthouses and family homes, each one walked through, photographed room by room and filmed before you visit.',
    phone: '+91 98765 43210',
    whatsapp: '919876543210',
    email: 'hello@aurelia-estates.example',
    office: '12th Floor, Crescent Tower, Linking Road, Bandra West, Mumbai 400050',
    rera: 'RERA registration no. P51800000000 (replace with your own)',
    about: 'We are a small team that sells fewer homes and knows each one properly. Every listing here has been visited, measured and photographed by us, with a video tour and, where possible, a walk-around 3D view so you can decide before you travel.',
    instagram: '', facebook: '', youtube: '',
    adminPass: 'admin123',
  };

  /* ---------- IndexedDB (with in-memory fallback) ---------- */
  const DB = {
    db: null, mem: null,
    async open() {
      try {
        this.db = await new Promise((res, rej) => {
          const r = indexedDB.open('premium-realty', 1);
          r.onupgradeneeded = () => { ['props', 'leads', 'media'].forEach((n) => r.result.createObjectStore(n, { keyPath: 'id' })); r.result.createObjectStore('kv', { keyPath: 'k' }); };
          r.onsuccess = () => res(r.result);
          r.onerror = () => rej(r.error);
          r.onblocked = () => rej(new Error('blocked'));
        });
      } catch (e) {
        this.db = null;
        this.mem = { props: new Map(), leads: new Map(), media: new Map(), kv: new Map() };
      }
    },
    _tx(store, mode, fn) {
      return new Promise((res, rej) => {
        const t = this.db.transaction(store, mode);
        const req = fn(t.objectStore(store));
        t.oncomplete = () => res(req ? req.result : undefined);
        t.onerror = () => rej(t.error);
        t.onabort = () => rej(t.error);
      });
    },
    getAll(s) { return this.mem ? Promise.resolve(Array.from(this.mem[s].values())) : this._tx(s, 'readonly', (o) => o.getAll()); },
    get(s, k) { return this.mem ? Promise.resolve(this.mem[s].get(k)) : this._tx(s, 'readonly', (o) => o.get(k)); },
    put(s, v) {
      if (this.mem) { this.mem[s].set(v.id !== undefined ? v.id : v.k, v); return Promise.resolve(); }
      return this._tx(s, 'readwrite', (o) => o.put(v));
    },
    del(s, k) { if (this.mem) { this.mem[s].delete(k); return Promise.resolve(); } return this._tx(s, 'readwrite', (o) => o.delete(k)); },
    clear(s) { if (this.mem) { this.mem[s].clear(); return Promise.resolve(); } return this._tx(s, 'readwrite', (o) => o.clear()); },
  };

  const urlCache = new Map(); // media id -> object URL (demo mode)
  const session = { get(k) { try { return sessionStorage.getItem(k); } catch (e) { return this['_' + k] || null; } }, set(k, v) { try { sessionStorage.setItem(k, v); } catch (e) { this['_' + k] = v; } }, del(k) { try { sessionStorage.removeItem(k); } catch (e) { delete this['_' + k]; } } };

  /* =====================================================================
     Shared helpers
     ===================================================================== */
  function refKey(r) { return r && (r.k === 'sb' ? 'sb:' + r.id : 'idb:' + r.id); }
  function sortProps(a) { return a.sort((x, y) => (y.featured ? 1 : 0) - (x.featured ? 1 : 0) || (y.createdAt || 0) - (x.createdAt || 0)); }

  const Store = {
    mode: SB_MODE ? 'supabase' : 'demo',
    props: [], settings: Object.assign({}, DEFAULT_SETTINGS), leads: [],
    justSeeded: false,

    url(ref) {
      if (!ref) return '';
      if (ref.k === 'sb') return ref.url || '';
      return urlCache.get(ref.id) || '';
    },
    async prime(refs) {
      const need = [];
      (refs || []).forEach((r) => { if (r && r.k === 'idb' && !urlCache.has(r.id) && need.indexOf(r.id) < 0) need.push(r.id); });
      await Promise.all(need.map(async (id) => {
        const m = await DB.get('media', id);
        if (m && m.blob) urlCache.set(id, URL.createObjectURL(m.blob));
      }));
    },
    getProp(id) { return Store.props.find((p) => p.id === id) || null; },
    getSettings() { return Store.settings; },

    /* Delete media that the saved version no longer uses and no other home shares. */
    async _gc(oldProp, newProp) {
      const keep = new Set();
      Store.props.forEach((p) => { if (!newProp || p.id !== newProp.id) RE.refsOf(p).forEach((r) => keep.add(refKey(r))); });
      if (newProp) RE.refsOf(newProp).forEach((r) => keep.add(refKey(r)));
      const drop = RE.refsOf(oldProp).filter((r) => !keep.has(refKey(r)));
      await Store.deleteMedia(drop);
    },
  };

  /* =====================================================================
     DEMO MODE (IndexedDB)
     ===================================================================== */
  const Demo = {
    async init(onProgress) {
      await DB.open();
      Store.props = sortProps(await DB.getAll('props'));
      const s = await DB.get('kv', 'settings');
      Store.settings = Object.assign({}, DEFAULT_SETTINGS, s ? s.v : {});
      Store.leads = (await DB.getAll('leads')).sort((a, b) => b.createdAt - a.createdAt);
      const seeded = await DB.get('kv', 'seeded');
      if (!Store.props.length && !seeded && cfg.sampleData && RE.seed) {
        await RE.seed.run(Store, onProgress);
        await DB.put('kv', { k: 'seeded', v: 1 });
        Store.props = sortProps(await DB.getAll('props'));
        Store.justSeeded = true;
      }
    },
    async saveProp(p) {
      const old = Store.getProp(p.id);
      p.updatedAt = Date.now();
      await DB.put('props', RE.clone(p));
      const i = Store.props.findIndex((x) => x.id === p.id);
      if (i >= 0) Store.props[i] = RE.clone(p); else Store.props.push(RE.clone(p));
      sortProps(Store.props);
      if (old) await Store._gc(old, p);
      return p;
    },
    async deleteProp(id) {
      const old = Store.getProp(id);
      await DB.del('props', id);
      Store.props = Store.props.filter((p) => p.id !== id);
      if (old) await Store._gc(old, null);
    },
    async saveSettings(s) { Store.settings = Object.assign({}, Store.settings, s); await DB.put('kv', { k: 'settings', v: Store.settings }); },
    async addLead(l) { const lead = Object.assign({ id: RE.uid('lead'), status: 'new', createdAt: Date.now() }, l); await DB.put('leads', lead); Store.leads.unshift(lead); return lead; },
    async loadLeads() { Store.leads = (await DB.getAll('leads')).sort((a, b) => b.createdAt - a.createdAt); return Store.leads; },
    async setLeadStatus(id, status) { const l = Store.leads.find((x) => x.id === id); if (l) { l.status = status; await DB.put('leads', l); } },
    async deleteLead(id) { await DB.del('leads', id); Store.leads = Store.leads.filter((l) => l.id !== id); },
    async putMedia(blob, meta) {
      const id = RE.uid('m');
      await DB.put('media', { id, blob, type: blob.type, name: (meta && meta.name) || '' });
      urlCache.set(id, URL.createObjectURL(blob));
      return { id, k: 'idb', t: /^video/.test(blob.type || (meta && meta.type) || '') ? 'video' : 'image', n: (meta && meta.name) || '' };
    },
    async deleteMedia(refs) {
      for (const r of refs || []) {
        if (!r || r.k !== 'idb') continue;
        await DB.del('media', r.id);
        const u = urlCache.get(r.id); if (u) { URL.revokeObjectURL(u); urlCache.delete(r.id); }
      }
    },
    async resetDemo() {
      await Promise.all(['props', 'leads', 'media', 'kv'].map((s) => DB.clear(s)));
      urlCache.forEach((u) => URL.revokeObjectURL(u)); urlCache.clear();
      Store.props = []; Store.leads = []; Store.settings = Object.assign({}, DEFAULT_SETTINGS);
    },
    auth: {
      fields: 'passcode',
      isAdmin() { return session.get('re_admin') === '1'; },
      async login(pass) {
        if (String(pass) === String(Store.settings.adminPass)) { session.set('re_admin', '1'); return true; }
        throw new Error('That passcode is not correct.');
      },
      logout() { session.del('re_admin'); },
    },
  };

  /* =====================================================================
     SUPABASE MODE (plain fetch against the REST / Auth / Storage APIs)
     ===================================================================== */
  const SB = { token: null, refresh: null, exp: 0, user: null, admin: false };
  function sbSave() { try { localStorage.setItem('re_sb', JSON.stringify({ t: SB.token, r: SB.refresh, e: SB.exp, u: SB.user, a: SB.admin })); } catch (e) { /* ignore */ } }
  function sbLoad() { try { const j = JSON.parse(localStorage.getItem('re_sb') || 'null'); if (j) { SB.token = j.t; SB.refresh = j.r; SB.exp = j.e; SB.user = j.u; SB.admin = !!j.a; } } catch (e) { /* ignore */ } }
  function sbClear() { SB.token = SB.refresh = SB.user = null; SB.exp = 0; SB.admin = false; try { localStorage.removeItem('re_sb'); } catch (e) { /* ignore */ } }
  const base = (cfg.supabaseUrl || '').replace(/\/+$/, '');

  async function sbFresh() {
    if (SB.token && SB.exp && Date.now() / 1000 > SB.exp - 60 && SB.refresh) {
      try {
        const r = await fetch(base + '/auth/v1/token?grant_type=refresh_token', { method: 'POST', headers: { apikey: cfg.supabaseAnonKey, 'Content-Type': 'application/json' }, body: JSON.stringify({ refresh_token: SB.refresh }) });
        if (r.ok) { const j = await r.json(); SB.token = j.access_token; SB.refresh = j.refresh_token; SB.exp = j.expires_at || Math.floor(Date.now() / 1000) + (j.expires_in || 3600); sbSave(); } else sbClear();
      } catch (e) { /* offline: keep going */ }
    }
  }
  async function sb(path, opt) {
    opt = opt || {};
    await sbFresh();
    const headers = Object.assign({ apikey: cfg.supabaseAnonKey, Authorization: 'Bearer ' + (SB.token || cfg.supabaseAnonKey) }, opt.headers || {});
    if (opt.json !== undefined) { headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(opt.json); }
    const r = await fetch(base + path, { method: opt.method || 'GET', headers, body: opt.body });
    if (!r.ok) {
      let msg = r.status + ' ' + r.statusText;
      try { const j = await r.json(); msg = j.message || j.error_description || j.error || msg; } catch (e) { /* ignore */ }
      throw new Error(msg);
    }
    const txt = await r.text();
    return txt ? JSON.parse(txt) : null;
  }
  const rowToProp = (r) => Object.assign({}, r.data, { id: r.id, createdAt: r.data && r.data.createdAt ? r.data.createdAt : Date.parse(r.created_at) || Date.now() });

  const Supa = {
    async init() {
      sbLoad();
      const rows = await sb('/rest/v1/properties?select=id,data,created_at&order=created_at.desc');
      Store.props = sortProps((rows || []).map(rowToProp));
      try {
        const s = await sb('/rest/v1/settings?id=eq.1&select=data');
        if (s && s[0]) Store.settings = Object.assign({}, DEFAULT_SETTINGS, s[0].data);
      } catch (e) { /* settings row may not exist yet */ }
      delete Store.settings.adminPass;
    },
    async saveProp(p) {
      const old = Store.getProp(p.id);
      p.updatedAt = Date.now();
      const body = { id: p.id, data: RE.clone(p) };
      await sb('/rest/v1/properties', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, json: body });
      const i = Store.props.findIndex((x) => x.id === p.id);
      if (i >= 0) Store.props[i] = RE.clone(p); else Store.props.push(RE.clone(p));
      sortProps(Store.props);
      if (old) await Store._gc(old, p);
      return p;
    },
    async deleteProp(id) {
      const old = Store.getProp(id);
      await sb('/rest/v1/properties?id=eq.' + encodeURIComponent(id), { method: 'DELETE' });
      Store.props = Store.props.filter((p) => p.id !== id);
      if (old) await Store._gc(old, null);
    },
    async saveSettings(s) {
      const next = Object.assign({}, Store.settings, s); delete next.adminPass;
      await sb('/rest/v1/settings', { method: 'POST', headers: { Prefer: 'resolution=merge-duplicates,return=minimal' }, json: { id: 1, data: next } });
      Store.settings = next;
    },
    async addLead(l) {
      await sb('/rest/v1/leads', { method: 'POST', headers: { Prefer: 'return=minimal' }, json: {
        property_id: l.propertyId || null, property_title: l.propertyTitle || null, kind: l.kind || 'enquiry',
        name: l.name, phone: l.phone, email: l.email || null, message: l.message || null,
        visit_date: l.visitDate || null, visit_time: l.visitTime || null } });
      return l;
    },
    async loadLeads() {
      const rows = await sb('/rest/v1/leads?select=*&order=created_at.desc');
      Store.leads = (rows || []).map((r) => ({ id: r.id, propertyId: r.property_id, propertyTitle: r.property_title, kind: r.kind, name: r.name, phone: r.phone, email: r.email, message: r.message, visitDate: r.visit_date, visitTime: r.visit_time, status: r.status, createdAt: Date.parse(r.created_at) }));
      return Store.leads;
    },
    async setLeadStatus(id, status) { await sb('/rest/v1/leads?id=eq.' + encodeURIComponent(id), { method: 'PATCH', headers: { Prefer: 'return=minimal' }, json: { status } }); const l = Store.leads.find((x) => x.id === id); if (l) l.status = status; },
    async deleteLead(id) { await sb('/rest/v1/leads?id=eq.' + encodeURIComponent(id), { method: 'DELETE' }); Store.leads = Store.leads.filter((l) => l.id !== id); },
    async putMedia(blob, meta) {
      const ext = (blob.type.split('/')[1] || 'bin').replace(/[^a-z0-9]/gi, '').slice(0, 5) || 'bin';
      const folder = (meta && meta.folder) || 'misc';
      const path = folder + '/' + RE.uid('f') + '.' + ext;
      await sbFresh();
      const r = await fetch(base + '/storage/v1/object/' + cfg.bucket + '/' + path, { method: 'POST', headers: { apikey: cfg.supabaseAnonKey, Authorization: 'Bearer ' + (SB.token || cfg.supabaseAnonKey), 'Content-Type': blob.type || 'application/octet-stream', 'x-upsert': 'false' }, body: blob });
      if (!r.ok) { let m = r.status + ''; try { m = (await r.json()).message || m; } catch (e) { /* ignore */ } throw new Error('Upload failed: ' + m); }
      return { id: path, k: 'sb', url: base + '/storage/v1/object/public/' + cfg.bucket + '/' + path, t: /^video/.test(blob.type) ? 'video' : 'image', n: (meta && meta.name) || '' };
    },
    async deleteMedia(refs) {
      for (const r of refs || []) {
        if (!r || r.k !== 'sb') continue;
        try { await sb('/storage/v1/object/' + cfg.bucket + '/' + r.id, { method: 'DELETE' }); } catch (e) { /* ignore, file may be gone */ }
      }
    },
    async resetDemo() { throw new Error('Reset is only for demo mode.'); },
    auth: {
      fields: 'email',
      isAdmin() { return !!(SB.token && SB.admin); },
      async login(email, pass) {
        const r = await fetch(base + '/auth/v1/token?grant_type=password', { method: 'POST', headers: { apikey: cfg.supabaseAnonKey, 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password: pass }) });
        const j = await r.json().catch(() => ({}));
        if (!r.ok) throw new Error(j.error_description || j.msg || 'Sign-in failed. Check your email and password.');
        SB.token = j.access_token; SB.refresh = j.refresh_token; SB.user = (j.user && j.user.id) || null;
        SB.exp = j.expires_at || Math.floor(Date.now() / 1000) + (j.expires_in || 3600);
        const rows = await sb('/rest/v1/admins?select=user_id&user_id=eq.' + encodeURIComponent(SB.user));
        SB.admin = !!(rows && rows.length);
        if (!SB.admin) { sbClear(); throw new Error('This account is not an admin. Add its user id to the admins table (see README).'); }
        sbSave();
        return true;
      },
      logout() { sbClear(); },
    },
  };

  /* Pick the back end and expose one API */
  const impl = SB_MODE ? Supa : Demo;
  Store.auth = impl.auth;
  ['saveProp', 'deleteProp', 'saveSettings', 'addLead', 'loadLeads', 'setLeadStatus', 'deleteLead', 'putMedia', 'deleteMedia', 'resetDemo'].forEach((k) => { Store[k] = impl[k].bind(impl); });
  Store.init = (onProgress) => impl.init(onProgress);
  Store.exportJSON = () => JSON.stringify({ exportedAt: new Date().toISOString(), settings: Object.assign({}, Store.settings, { adminPass: undefined }), properties: Store.props }, null, 2);
  RE.store = Store;
})();
