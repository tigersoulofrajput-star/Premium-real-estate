/* util.js - small helpers shared by every part of the site (no libraries needed) */
(function () {
  'use strict';
  const RE = (window.RE = window.RE || {});
  RE.cfg = Object.assign(
    { supabaseUrl: '', supabaseAnonKey: '', bucket: 'property-media', embedMaps: true, sampleData: true },
    window.RE_CONFIG || {}
  );

  /* ---------- DOM ---------- */
  RE.$ = (s, r) => (r || document).querySelector(s);
  RE.$$ = (s, r) => Array.from((r || document).querySelectorAll(s));

  RE.h = function h(tag, attrs, ...kids) {
    const el = document.createElement(tag);
    let pendingValue;
    if (attrs) {
      for (const [k, v] of Object.entries(attrs)) {
        if (v == null || v === false) continue;
        if (k === 'class') el.className = v;
        else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
        else if (k.slice(0, 2) === 'on' && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
        else if (k === 'value') pendingValue = v;
        else if (k === 'checked' || k === 'disabled' || k === 'selected' || k === 'hidden' || k === 'multiple') el[k] = !!v;
        else el.setAttribute(k, v === true ? '' : v);
      }
    }
    const add = (c) => {
      if (c == null || c === false) return;
      if (Array.isArray(c)) c.forEach(add);
      else el.appendChild(c.nodeType ? c : document.createTextNode(String(c)));
    };
    kids.forEach(add);
    if (pendingValue !== undefined) el.value = pendingValue;
    return el;
  };
  RE.clear = (el) => { while (el.firstChild) el.removeChild(el.firstChild); return el; };

  /* ---------- icons (static, trusted strings) ---------- */
  const ICONS = {
    bed: '<path d="M3 18v-7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v7M3 15h18M3 18v2M21 18v2M7 9V7h4v2"/>',
    bath: '<path d="M4 12h16v3a4 4 0 0 1-4 4H8a4 4 0 0 1-4-4v-3zM6 12V6a2 2 0 0 1 4 0M7 19l-1 2M17 19l1 2"/>',
    area: '<path d="M4 4h6M4 4v6M20 20h-6M20 20v-6M4 20l6-6M20 4l-6 6"/>',
    car: '<path d="M5 16V11l2-5h10l2 5v5M3 16h18M7 19v-3M17 19v-3M7 12h10"/>',
    compass: '<circle cx="12" cy="12" r="9"/><path d="M15.5 8.5l-2 5-5 2 2-5z"/>',
    layers: '<path d="M12 3l9 5-9 5-9-5zM3 13l9 5 9-5"/>',
    pin: '<path d="M12 21s7-6.2 7-11a7 7 0 0 0-14 0c0 4.8 7 11 7 11z"/><circle cx="12" cy="10" r="2.5"/>',
    phone: '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>',
    play: '<circle cx="12" cy="12" r="9"/><path d="M10 8.5l6 3.5-6 3.5z"/>',
    cube: '<path d="M12 3l8 4.5v9L12 21l-8-4.5v-9zM12 12l8-4.5M12 12L4 7.5M12 12v9"/>',
    pano: '<path d="M3 8c6-3 12-3 18 0v8c-6-3-12-3-18 0zM8 11.5c2.7 1 5.3 1 8 0"/>',
    image: '<rect x="3" y="4" width="18" height="16" rx="2"/><circle cx="9" cy="10" r="1.6"/><path d="M21 16l-5-5-8 8"/>',
    map: '<path d="M9 4L3 6v14l6-2 6 2 6-2V4l-6 2zM9 4v14M15 6v14"/>',
    doc: '<path d="M6 3h8l4 4v14H6zM14 3v4h4M9 12h6M9 16h6"/>',
    plus: '<path d="M12 5v14M5 12h14"/>',
    trash: '<path d="M4 7h16M10 11v6M14 11v6M6 7l1 13h10l1-13M9 7V4h6v3"/>',
    edit: '<path d="M4 20h4L19 9l-4-4L4 16zM13.5 6.5l4 4"/>',
    arrowR: '<path d="M5 12h14M13 6l6 6-6 6"/>',
    arrowL: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
    check: '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
    close: '<path d="M6 6l12 12M18 6L6 18"/>',
    chevL: '<path d="M15 5l-7 7 7 7"/>',
    chevR: '<path d="M9 5l7 7-7 7"/>',
    star: '<path d="M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.9-5.2-2.8-5.2 2.8 1-5.9L3.5 9.7l5.9-.8z"/>',
    upload: '<path d="M12 16V4M7 9l5-5 5 5M4 16v4h16v-4"/>',
    eye: '<path d="M2 12s3.6-6.5 10-6.5S22 12 22 12s-3.6 6.5-10 6.5S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    users: '<circle cx="9" cy="8" r="3.2"/><path d="M3 20a6 6 0 0 1 12 0M16 5a3.2 3.2 0 0 1 0 6M18 14a6 6 0 0 1 3 6"/>',
    cog: '<circle cx="12" cy="12" r="3"/><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/>',
    home: '<path d="M4 11l8-7 8 7M6 10v10h12V10M10 20v-5h4v5"/>',
    mail: '<rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 7l9 6 9-6"/>',
    calendar: '<rect x="4" y="5" width="16" height="15" rx="2"/><path d="M4 10h16M8 3v4M16 3v4"/>',
    shield: '<path d="M12 3l8 3v6c0 4.4-3.2 7.6-8 9-4.8-1.4-8-4.6-8-9V6z"/><path d="M9 12l2.2 2.2L15.5 10"/>',
    hand: '<path d="M8 12V6a1.5 1.5 0 0 1 3 0v5M11 11V4.5a1.5 1.5 0 0 1 3 0V11M14 11V6a1.5 1.5 0 0 1 3 0v8c0 4-2.5 6-5.5 6S7 18 6 15l-1.4-3.5a1.5 1.5 0 0 1 2.6-1.3z"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    left: '<path d="M10 6l-6 6 6 6M4 12h16"/>',
    rotate: '<path d="M4 12a8 8 0 0 1 14-5l2 2M20 4v5h-5M20 12a8 8 0 0 1-14 5l-2-2M4 20v-5h5"/>',
    grip: '<path d="M9 6h.01M15 6h.01M9 12h.01M15 12h.01M9 18h.01M15 18h.01"/>',
    download: '<path d="M12 4v12M7 11l5 5 5-5M4 20h16"/>',
    logout: '<path d="M10 4H5v16h5M15 8l4 4-4 4M19 12H9"/>',
    key: '<circle cx="8" cy="15" r="4"/><path d="M11 12l9-9M16 7l3 3"/>',
  };
  RE.icon = function (name, size) {
    const s = document.createElement('span');
    s.className = 'ico';
    s.setAttribute('aria-hidden', 'true');
    const px = size || 18;
    s.innerHTML =
      '<svg viewBox="0 0 24 24" width="' + px + '" height="' + px +
      '" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">' +
      (ICONS[name] || '') + '</svg>';
    return s;
  };

  /* ---------- formatting ---------- */
  RE.inr = (n) => '₹' + new Intl.NumberFormat('en-IN').format(Math.round(+n || 0));
  RE.inrShort = (n) => {
    n = +n || 0;
    if (n >= 1e7) return '₹' + +(n / 1e7).toFixed(2) + ' Cr';
    if (n >= 1e5) return '₹' + +(n / 1e5).toFixed(2) + ' L';
    return RE.inr(n);
  };
  RE.priceText = (p) => RE.inrShort(p.price) + (p.status === 'rent' ? ' / month' : '');
  RE.statusText = (s) => ({ sale: 'For sale', rent: 'For rent', sold: 'Sold' }[s] || s);
  RE.fmtDate = (t) => {
    try { return new Date(t).toLocaleString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: 'numeric', minute: '2-digit' }); }
    catch (e) { return ''; }
  };
  RE.digits = (s) => String(s || '').replace(/\D+/g, '');
  RE.uid = (p) => (p || 'id') + '-' + Math.random().toString(36).slice(2, 8) + Date.now().toString(36).slice(-4);
  RE.slug = (s) => String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40) || 'room';
  RE.clamp = (v, a, b) => Math.min(b, Math.max(a, v));
  RE.clone = (o) => JSON.parse(JSON.stringify(o));
  RE.debounce = (fn, ms) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
  RE.reducedMotion = () => { try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; } };
  RE.validEmail = (s) => /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(s || '').trim());
  RE.validPhone = (s) => { const d = RE.digits(s); return d.length >= 10 && d.length <= 13; };
  RE.natCompare = (a, b) => String(a).localeCompare(String(b), undefined, { numeric: true, sensitivity: 'base' });

  /* ---------- toast ---------- */
  RE.toast = function (msg, kind) {
    let box = RE.$('#toasts');
    if (!box) { box = RE.h('div', { id: 'toasts', 'aria-live': 'polite' }); document.body.appendChild(box); }
    const t = RE.h('div', { class: 'toast ' + (kind || '') }, msg);
    box.appendChild(t);
    setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 300); }, kind === 'error' ? 5200 : 2800);
  };

  /* ---------- images ---------- */
  RE.compressImage = async function (file, max, q) {
    max = max || 1800; q = q || 0.82;
    let bmp;
    try { bmp = await createImageBitmap(file); }
    catch (e) {
      bmp = await new Promise((res, rej) => {
        const img = new Image(); const u = URL.createObjectURL(file);
        img.onload = () => { res(img); };
        img.onerror = () => { URL.revokeObjectURL(u); rej(new Error('Cannot read ' + file.name + '. Use JPG, PNG or WebP.')); };
        img.src = u;
      });
    }
    const w0 = bmp.width, h0 = bmp.height;
    const s = Math.min(1, max / Math.max(w0, h0));
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(w0 * s)); c.height = Math.max(1, Math.round(h0 * s));
    c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
    if (bmp.close) bmp.close();
    const blob = await new Promise((r) => c.toBlob(r, 'image/jpeg', q));
    return { blob, w: c.width, h: c.height };
  };

  /* ---------- Google Maps input ---------- */
  RE.parseMap = function (input) {
    const out = { lat: null, lng: null, embed: '' };
    let s = String(input || '').trim();
    if (!s) return out;
    const m = s.match(/src=["']([^"']+)["']/i);
    if (m) s = m[1];
    s = s.replace(/&amp;/g, '&');
    if (/^https:\/\/www\.google\.com\/maps\/embed/i.test(s) || /^https:\/\/(www\.)?google\.com\/maps\?.*output=embed/i.test(s) || /^https:\/\/maps\.google\.com\/maps\?.*output=embed/i.test(s)) out.embed = s;
    const c =
      s.match(/@(-?\d{1,3}\.\d+),(-?\d{1,3}\.\d+)/) ||
      s.match(/!3d(-?\d{1,3}\.\d+)!4d(-?\d{1,3}\.\d+)/) ||
      s.match(/[?&](?:q|query|ll|center)=(-?\d{1,3}\.\d+)(?:,|%2C)\s*(-?\d{1,3}\.\d+)/i) ||
      s.match(/^\s*(-?\d{1,3}\.\d+)\s*[, ]\s*(-?\d{1,3}\.\d+)\s*$/);
    if (c) { out.lat = +c[1]; out.lng = +c[2]; }
    else {
      const pb = s.match(/!2d(-?\d+\.\d+)!3d(-?\d+\.\d+)/);
      if (pb) { out.lng = +pb[1]; out.lat = +pb[2]; }
    }
    if (out.lat != null && (Math.abs(out.lat) > 90 || Math.abs(out.lng) > 180)) { out.lat = out.lng = null; }
    return out;
  };
  RE.mapQuery = (p) => {
    const m = p.map || {};
    if (m.lat != null && m.lng != null) return m.lat + ',' + m.lng;
    return [p.address, p.locality, p.city].filter(Boolean).join(', ');
  };
  RE.mapEmbedSrc = (p) => {
    const m = p.map || {};
    if (m.embed && /^https:\/\/(www\.|maps\.)?google\.com\/maps/i.test(m.embed)) return m.embed;
    const q = RE.mapQuery(p);
    return q ? 'https://www.google.com/maps?q=' + encodeURIComponent(q) + '&z=16&output=embed' : '';
  };
  RE.mapLink = (p) => 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(RE.mapQuery(p));

  /* ---------- video URL -> embed ---------- */
  RE.videoEmbed = function (url) {
    url = String(url || '').trim();
    if (!/^https?:\/\//i.test(url)) return null;
    let m = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?(?:.*&)?v=|embed\/|shorts\/))([\w-]{6,})/i);
    if (m) return { kind: 'iframe', src: 'https://www.youtube.com/embed/' + m[1] + '?rel=0' };
    m = url.match(/vimeo\.com\/(?:video\/)?(\d+)/i);
    if (m) return { kind: 'iframe', src: 'https://player.vimeo.com/video/' + m[1] };
    return { kind: 'file', src: url };
  };

  /* ---------- misc ---------- */
  RE.download = function (name, text, type) {
    const b = new Blob([text], { type: type || 'text/plain' });
    const a = RE.h('a', { href: URL.createObjectURL(b), download: name });
    document.body.appendChild(a); a.click(); a.remove();
  };
  RE.csv = (rows) => rows.map((r) => r.map((v) => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"').join(',')).join('\n');

  RE.emi = function (principal, annualRate, years) {
    const n = Math.round(years * 12), r = annualRate / 12 / 100;
    if (principal <= 0 || n <= 0) return { emi: 0, total: 0, interest: 0 };
    const emi = r === 0 ? principal / n : (principal * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    return { emi, total: emi * n, interest: emi * n - principal };
  };

  /* property helpers */
  RE.refsOf = function (p) {
    const out = [];
    if (!p) return out;
    if (p.cover) out.push(p.cover);
    (p.rooms || []).forEach((r) => (r.photos || []).forEach((x) => out.push(x)));
    if (p.video && p.video.ref) out.push(p.video.ref);
    (p.spin || []).forEach((x) => out.push(x));
    if (p.pano) out.push(p.pano);
    return out;
  };
  RE.coverOf = (p) => p.cover || ((p.rooms || []).find((r) => r.photos && r.photos.length) || { photos: [] }).photos[0] || null;
  RE.photoCount = (p) => (p.rooms || []).reduce((n, r) => n + (r.photos || []).length, 0);
  RE.blankProperty = () => ({
    id: RE.uid('home'), status: 'sale', featured: false, type: 'Apartment', title: '', tagline: '',
    price: 0, priceNote: '', city: '', locality: '', address: '',
    map: { input: '', lat: null, lng: null, embed: '' },
    bhk: 3, bedrooms: 3, bathrooms: 3, area: 1500, floors: 1, parking: 1, facing: '', year: '', agentPhone: '',
    amenities: [], description: '', review: '', cover: null, rooms: [], video: { kind: '', url: '', ref: null },
    spin: [], pano: null, createdAt: Date.now(), updatedAt: Date.now(),
  });
})();
