/* viewers.js - walk-around 3D view (photo spin), 360 panorama, and the photo lightbox */
(function () {
  'use strict';
  const RE = window.RE, h = RE.h;

  /* =====================================================================
     SpinViewer: photos taken all the way around a house, drag to turn it
     ===================================================================== */
  RE.SpinViewer = function (container, urls, opts) {
    opts = opts || {};
    const n = urls.length;
    const canvas = h('canvas', { class: 'spin-canvas', tabindex: '0', role: 'img', 'aria-label': 'Walk-around 3D view. Drag left or right, or use the arrow keys, to turn the house.' });
    const loading = h('div', { class: 'viewer-loading' }, 'Loading 3D view...');
    const hint = h('div', { class: 'viewer-hint' }, RE.icon('hand', 16), 'Drag to walk around the house');
    const count = h('div', { class: 'viewer-count' });
    const play = h('button', { class: 'viewer-btn', type: 'button', 'aria-label': 'Pause automatic turning' }, RE.icon('pause', 16));
    const wrap = h('div', { class: 'spin' }, canvas, loading, hint, count, play);
    container.appendChild(wrap);
    const ctx = canvas.getContext('2d');
    const imgs = [];
    let pos = 0, auto = opts.autoplay !== false && !RE.reducedMotion(), dragging = false, lx = 0, vel = 0, raf = 0, dead = false, visible = true, last = 0, idleAt = 0, ready = false, ratio = 1.6;

    function frameIdx() { return ((Math.round(pos) % n) + n) % n; }
    function draw() {
      const im = imgs[frameIdx()];
      count.textContent = 'View ' + (frameIdx() + 1) + ' of ' + n;
      if (!im || !im.naturalWidth) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2), w = Math.max(2, Math.round(wrap.clientWidth * dpr)), hh = Math.round(w / ratio);
      if (canvas.width !== w || canvas.height !== hh) { canvas.width = w; canvas.height = hh; }
      ctx.drawImage(im, 0, 0, canvas.width, canvas.height);
    }
    let loaded = 0;
    urls.forEach((u, i) => {
      const im = new Image();
      im.onload = im.onerror = () => {
        loaded++;
        if (i === 0 && im.naturalWidth) { ratio = im.naturalWidth / im.naturalHeight; wrap.style.aspectRatio = ratio + ' / 1'; }
        if (loaded === n) { ready = true; loading.hidden = true; draw(); }
        else loading.textContent = 'Loading 3D view... ' + Math.round((loaded / n) * 100) + '%';
      };
      im.src = u; imgs[i] = im;
    });

    const cleanup = [];
    const on = (el, ev, fn) => { el.addEventListener(ev, fn); cleanup.push(() => el.removeEventListener(ev, fn)); };
    canvas.style.touchAction = 'pan-y';
    on(canvas, 'pointerdown', (e) => { dragging = true; lx = e.clientX; vel = 0; try { canvas.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ } hint.classList.add('gone'); });
    on(canvas, 'pointermove', (e) => { if (!dragging) return; const dx = e.clientX - lx; lx = e.clientX; const d = (-dx * n) / (wrap.clientWidth * 1.1); pos += d; vel = d; draw(); });
    const end = () => { dragging = false; idleAt = performance.now(); };
    on(canvas, 'pointerup', end); on(canvas, 'pointercancel', end); on(canvas, 'lostpointercapture', end);
    on(canvas, 'keydown', (e) => { if (e.key === 'ArrowLeft') pos -= 1; else if (e.key === 'ArrowRight') pos += 1; else return; e.preventDefault(); draw(); });
    on(play, 'click', () => {
      auto = !auto; play.replaceChildren(RE.icon(auto ? 'pause' : 'play', 16));
      play.setAttribute('aria-label', auto ? 'Pause automatic turning' : 'Start automatic turning');
    });
    if (!auto) play.replaceChildren(RE.icon('play', 16));
    if ('IntersectionObserver' in window) { const io = new IntersectionObserver((en) => { visible = en[0].isIntersecting; }, { threshold: 0.05 }); io.observe(wrap); cleanup.push(() => io.disconnect()); }
    function tick(now) {
      if (dead) return; raf = requestAnimationFrame(tick);
      if (!visible || !ready) return;
      const dt = Math.min(0.05, (now - last) / 1000 || 0.016); last = now;
      let moved = false;
      if (!dragging && Math.abs(vel) > 0.01) { pos += vel; vel *= 0.92; moved = true; }
      else if (!dragging && auto && now - idleAt > 1500) { pos += dt * 6; moved = true; }
      if (moved) draw();
    }
    raf = requestAnimationFrame(tick);
    on(window, 'resize', () => { if (ready) draw(); });
    return { destroy() { dead = true; cancelAnimationFrame(raf); cleanup.forEach((f) => f()); wrap.remove(); } };
  };

  /* =====================================================================
     PanoViewer: one 360 photo (equirectangular), drag to look around
     ===================================================================== */
  const PV = 'attribute vec2 a_p;varying vec2 v_uv;void main(){v_uv=a_p*0.5+0.5;gl_Position=vec4(a_p,0.0,1.0);}';
  const PF = '#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n' +
    'uniform sampler2D u_tex;uniform float u_yaw,u_pitch,u_tan,u_asp;varying vec2 v_uv;' +
    'void main(){vec2 p=(v_uv*2.0-1.0)*vec2(u_asp*u_tan,u_tan);vec3 d=normalize(vec3(p.x,p.y,-1.0));' +
    'float cp=cos(u_pitch),sp=sin(u_pitch);d=vec3(d.x,d.y*cp-d.z*sp,d.y*sp+d.z*cp);' +
    'float cy=cos(u_yaw),sy=sin(u_yaw);d=vec3(d.x*cy+d.z*sy,d.y,-d.x*sy+d.z*cy);' +
    'float lon=atan(d.x,-d.z);float lat=asin(clamp(d.y,-1.0,1.0));' +
    'gl_FragColor=vec4(texture2D(u_tex,vec2(lon/6.2831853+0.5,0.5+lat/3.14159265)).rgb,1.0);}';

  RE.PanoViewer = function (container, url, opts) {
    opts = opts || {};
    const canvas = h('canvas', { class: 'pano-canvas', tabindex: '0', role: 'img', 'aria-label': '360 degree view. Drag to look around, or use the arrow keys.' });
    const loading = h('div', { class: 'viewer-loading' }, 'Loading 360 view...');
    const hint = h('div', { class: 'viewer-hint' }, RE.icon('hand', 16), 'Drag to look around');
    const zin = h('button', { class: 'viewer-btn zin', type: 'button', 'aria-label': 'Zoom in' }, RE.icon('plus', 16));
    const zout = h('button', { class: 'viewer-btn zout', type: 'button', 'aria-label': 'Zoom out' }, h('span', { class: 'minus' }));
    const wrap = h('div', { class: 'pano' }, canvas, loading, hint, zin, zout);
    container.appendChild(wrap);
    let dead = false, raf = 0;
    const cleanup = [];
    const gl = canvas.getContext('webgl', { antialias: false });
    if (!gl) { loading.hidden = true; wrap.appendChild(h('img', { class: 'pano-fallback', src: url, alt: '360 degree photo' })); return { destroy() { wrap.remove(); } }; }
    const mk = (t, s) => { const sh = gl.createShader(t); gl.shaderSource(sh, s); gl.compileShader(sh); return sh; };
    const pr = gl.createProgram(); gl.attachShader(pr, mk(gl.VERTEX_SHADER, PV)); gl.attachShader(pr, mk(gl.FRAGMENT_SHADER, PF)); gl.linkProgram(pr); gl.useProgram(pr);
    const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const ap = gl.getAttribLocation(pr, 'a_p'); gl.enableVertexAttribArray(ap); gl.vertexAttribPointer(ap, 2, gl.FLOAT, false, 0, 0);
    const tex = gl.createTexture();
    const U = (n) => gl.getUniformLocation(pr, n);
    const st = { yaw: 0, pitch: 0, fov: 78, vx: 0, ready: false, drag: false, lx: 0, ly: 0, idle: 0, visible: true };
    let last = 0;

    const img = new Image();
    if (!/^(blob:|data:)/.test(url)) img.crossOrigin = 'anonymous';
    img.onload = () => {
      const max = Math.min(4096, gl.getParameter(gl.MAX_TEXTURE_SIZE));
      const W = img.naturalWidth >= 3000 && max >= 4096 ? 4096 : 2048, H = W / 2;
      const c = document.createElement('canvas'); c.width = W; c.height = H; c.getContext('2d').drawImage(img, 0, 0, W, H);
      gl.bindTexture(gl.TEXTURE_2D, tex); gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
      gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, c);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      st.ready = true; loading.hidden = true; render();
    };
    img.onerror = () => { loading.textContent = 'This 360 photo could not be loaded.'; };
    img.src = url;

    function render() {
      const dpr = Math.min(window.devicePixelRatio || 1, 2), w = Math.max(2, Math.round(canvas.clientWidth * dpr)), hh = Math.max(2, Math.round(canvas.clientHeight * dpr));
      if (canvas.width !== w || canvas.height !== hh) { canvas.width = w; canvas.height = hh; }
      gl.viewport(0, 0, w, hh);
      gl.uniform1f(U('u_yaw'), st.yaw); gl.uniform1f(U('u_pitch'), st.pitch); gl.uniform1f(U('u_tan'), Math.tan((st.fov * Math.PI) / 360)); gl.uniform1f(U('u_asp'), w / hh);
      gl.drawArrays(gl.TRIANGLES, 0, 3);
    }
    const on = (el, ev, fn, o) => { el.addEventListener(ev, fn, o); cleanup.push(() => el.removeEventListener(ev, fn, o)); };
    canvas.style.touchAction = 'none'; canvas.style.cursor = 'grab';
    on(canvas, 'pointerdown', (e) => { st.drag = true; st.lx = e.clientX; st.ly = e.clientY; st.vx = 0; try { canvas.setPointerCapture(e.pointerId); } catch (x) { /* ignore */ } hint.classList.add('gone'); canvas.style.cursor = 'grabbing'; });
    on(canvas, 'pointermove', (e) => {
      if (!st.drag) return;
      const k = ((st.fov * Math.PI) / 180) / canvas.clientHeight;
      const dx = e.clientX - st.lx, dy = e.clientY - st.ly; st.lx = e.clientX; st.ly = e.clientY;
      st.yaw += dx * k; st.vx = dx * k; st.pitch = RE.clamp(st.pitch + dy * k, -1.45, 1.45); render();
    });
    const end = () => { st.drag = false; st.idle = performance.now(); canvas.style.cursor = 'grab'; };
    on(canvas, 'pointerup', end); on(canvas, 'pointercancel', end); on(canvas, 'lostpointercapture', end);
    on(canvas, 'keydown', (e) => {
      if (e.key === 'ArrowLeft') st.yaw -= 0.1; else if (e.key === 'ArrowRight') st.yaw += 0.1; else if (e.key === 'ArrowUp') st.pitch = RE.clamp(st.pitch + 0.08, -1.45, 1.45); else if (e.key === 'ArrowDown') st.pitch = RE.clamp(st.pitch - 0.08, -1.45, 1.45); else return;
      e.preventDefault(); render();
    });
    on(zin, 'click', () => { st.fov = RE.clamp(st.fov - 12, 35, 100); render(); });
    on(zout, 'click', () => { st.fov = RE.clamp(st.fov + 12, 35, 100); render(); });
    on(window, 'resize', () => { if (st.ready) render(); });
    if ('IntersectionObserver' in window) { const io = new IntersectionObserver((en) => { st.visible = en[0].isIntersecting; }, { threshold: 0.05 }); io.observe(wrap); cleanup.push(() => io.disconnect()); }
    function tick(now) {
      if (dead) return; raf = requestAnimationFrame(tick);
      if (!st.ready || !st.visible) return;
      const dt = Math.min(0.05, (now - last) / 1000 || 0.016); last = now;
      if (!st.drag) {
        if (Math.abs(st.vx) > 0.0002) { st.yaw += st.vx; st.vx *= 0.94; render(); }
        else if (opts.autoRotate !== false && !RE.reducedMotion() && now - st.idle > 2500) { st.yaw += dt * 0.08; render(); }
      }
    }
    raf = requestAnimationFrame(tick);
    return { destroy() { dead = true; cancelAnimationFrame(raf); cleanup.forEach((f) => f()); const x = gl.getExtension('WEBGL_lose_context'); if (x) x.loseContext(); wrap.remove(); } };
  };

  /* =====================================================================
     Lightbox: full-screen photos with arrows, keys and swipe
     ===================================================================== */
  RE.lightbox = {
    el: null, items: [], i: 0, opener: null, onKey: null,
    open(items, index, opener) {
      this.close(true);
      this.items = items; this.i = index || 0; this.opener = opener || document.activeElement;
      const img = h('img', { alt: '' });
      const cap = h('div', { class: 'lb-cap' });
      const cnt = h('div', { class: 'lb-count' });
      const close = h('button', { class: 'lb-btn lb-close', type: 'button', 'aria-label': 'Close photo viewer', onclick: () => this.close() }, RE.icon('close', 22));
      const prev = h('button', { class: 'lb-btn lb-prev', type: 'button', 'aria-label': 'Previous photo', onclick: () => this.go(-1) }, RE.icon('chevL', 24));
      const next = h('button', { class: 'lb-btn lb-next', type: 'button', 'aria-label': 'Next photo', onclick: () => this.go(1) }, RE.icon('chevR', 24));
      const stage = h('div', { class: 'lb-stage' }, img);
      const el = h('div', { class: 'lb', role: 'dialog', 'aria-modal': 'true', 'aria-label': 'Photo viewer' }, stage, close, prev, next, h('div', { class: 'lb-meta' }, cap, cnt));
      this.el = el; this.img = img; this.cap = cap; this.cnt = cnt; this.prev = prev; this.next = next;
      el.addEventListener('click', (e) => { if (e.target === el || e.target === stage) this.close(); });
      let sx = null;
      stage.addEventListener('pointerdown', (e) => { sx = e.clientX; });
      stage.addEventListener('pointerup', (e) => { if (sx == null) return; const d = e.clientX - sx; sx = null; if (Math.abs(d) > 50) this.go(d < 0 ? 1 : -1); });
      this.onKey = (e) => { if (e.key === 'Escape') this.close(); else if (e.key === 'ArrowRight') this.go(1); else if (e.key === 'ArrowLeft') this.go(-1); };
      document.addEventListener('keydown', this.onKey);
      document.body.appendChild(el); document.body.classList.add('lb-open');
      this.show(); close.focus();
    },
    show() {
      const it = this.items[this.i]; if (!it) return;
      this.img.src = it.url; this.img.alt = it.caption || 'Property photo';
      this.cap.textContent = it.caption || ''; this.cnt.textContent = (this.i + 1) + ' / ' + this.items.length;
      this.prev.hidden = this.next.hidden = this.items.length < 2;
    },
    go(d) { this.i = (this.i + d + this.items.length) % this.items.length; this.show(); },
    close(silent) {
      if (!this.el) return;
      document.removeEventListener('keydown', this.onKey); this.el.remove(); this.el = null; document.body.classList.remove('lb-open');
      if (!silent && this.opener && this.opener.focus) { try { this.opener.focus(); } catch (e) { /* ignore */ } }
    },
  };
})();
